#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"
#include "mqtt_client.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "DHT22.h"
#include "lwip/sockets.h"
#include "lwip/dns.h"
#include "lwip/netdb.h"
#include "freertos/event_groups.h"
#include "lwip/err.h"
#include "lwip/sys.h"
#include "esp_wifi.h"
#include "ssd1306.h"
#include "esp_sntp.h"
#include <time.h>

static const char *TAG = "mqtt_dht22";  // Tag untuk logging ESP

// --- PIN KONFIGURASI ---
#define I2C_MASTER_SDA_IO 8  // Pin SDA untuk I2C (OLED)
#define I2C_MASTER_SCL_IO 9  // Pin SCL untuk I2C (OLED)
#define DHT_GPIO 4           // Pin data untuk sensor DHT22

#define CONFIG_ESP_MAXIMUM_RETRY 6  // Jumlah maksimum retry koneksi
#define EXAMPLE_ESP_WIFI_SSID      "Kelas"       // SSID WiFi
#define EXAMPLE_ESP_WIFI_PASS      "Mahasisw4!!" // Password WiFi
#define EXAMPLE_ESP_MAXIMUM_RETRY  CONFIG_ESP_MAXIMUM_RETRY

#define WIFI_CONNECTED_BIT BIT0  // Bit event group untuk WiFi terhubung
#define WIFI_FAIL_BIT      BIT1  // Bit event group untuk WiFi gagal

static EventGroupHandle_t s_wifi_event_group;  // Event group untuk sinkronisasi WiFi
static int s_retry_num = 0;                    // Counter retry koneksi WiFi
static esp_mqtt_client_handle_t mqtt_client;   // Handle client MQTT

// --- SNTP (NTP) ---
void obtain_time(void) {
    sntp_setoperatingmode(SNTP_OPMODE_POLL);  // Set mode polling
    sntp_setservername(0, "pool.ntp.org");    // Set server NTP
    sntp_init();                              // Inisialisasi SNTP

    // Tunggu waktu tersinkronisasi
    time_t now = 0;
    struct tm timeinfo = { 0 };
    int retry = 0;
    const int retry_count = 10;
    while (timeinfo.tm_year < (2016 - 1900) && ++retry < retry_count) {
        ESP_LOGI(TAG, "Waiting for system time to be set... (%d/%d)", retry, retry_count);
        vTaskDelay(2000 / portTICK_PERIOD_MS);
        time(&now);
        localtime_r(&now, &timeinfo);
    }
}

// Fungsi untuk menampilkan waktu, suhu, dan kelembapan di OLED
void oled_show_time_temp_hum(float temp, float hum)
{
    char line_time[16], line_date[24], line_temp[20], line_hum[20];
    const char *sep = "---------------------"; // 21 char ≈ 126 px (font 6 px/char)

    // Ambil waktu lokal
    time_t now;
    struct tm timeinfo;
    time(&now);
    localtime_r(&now, &timeinfo);

    // Format jam & hari/tanggal
    strftime(line_time, sizeof(line_time), "%H:%M", &timeinfo);       // contoh: 21:45
    strftime(line_date, sizeof(line_date), "%a %d-%m", &timeinfo);    // contoh: Mon 30-08

    // Format suhu & kelembapan
    snprintf(line_temp, sizeof(line_temp), "Temp: %.1fC", temp);
    snprintf(line_hum, sizeof(line_hum), "Hum : %.1f%%", hum);

    ssd1306_clear_screen();  // Bersihkan layar OLED

    // UMAR (atas, center)
    int x_hdr = (128 - (int)strlen("UMAR") * 6) / 2;
    ssd1306_draw_string(x_hdr, 0, "UMAR", 1, 0);

    // Garis pemisah atas
    ssd1306_draw_string(0, 1, sep, 1, 0);

    // Hari/tanggal (center)
    int x_date = (128 - (int)strlen(line_date) * 6) / 2;
    ssd1306_draw_string(x_date, 2, line_date, 1, 0);

    // Jam (center, ukuran normal)
    int x_time = (128 - (int)strlen(line_time) * 6) / 2;
    ssd1306_draw_string(x_time, 3, line_time, 1, 0);

    // Garis pemisah bawah
    ssd1306_draw_string(0, 4, sep, 1, 0);

    // Suhu kiri, Humidity kanan
    ssd1306_draw_string(0, 5, line_temp, 1, 0);
    int x_hum = 128 - (int)strlen(line_hum) * 6;
    if (x_hum < 0) x_hum = 0;
    ssd1306_draw_string(x_hum, 5, line_hum, 1, 0);

    // Tulisan paling bawah (center)
    int x_rpk = (128 - (int)strlen("2 RPK") * 6) / 2;
    ssd1306_draw_string(x_rpk, 7, "2 RPK", 1, 0);

    ssd1306_refresh_gram();  // Refresh layar OLED
}

// --- WIFI ---
// Event handler untuk event WiFi
static void event_handler(void* arg, esp_event_base_t event_base,
                          int32_t event_id, void* event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();  // Coba koneksi saat WiFi station start
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        if (s_retry_num < EXAMPLE_ESP_MAXIMUM_RETRY) {
            esp_wifi_connect();  // Retry koneksi
            s_retry_num++;
            ESP_LOGI(TAG, "retry to connect to the AP");
        } else {
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);  // Set bit fail
        }
        ESP_LOGI(TAG,"connect to the AP fail");
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        ESP_LOGI(TAG, "got ip:" IPSTR, IP2STR(&event->ip_info.ip));
        s_retry_num = 0;
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);  // Set bit connected
    }
}

// Inisialisasi WiFi station mode
void wifi_init_sta(void)
{
    s_wifi_event_group = xEventGroupCreate();  // Buat event group
    esp_netif_create_default_wifi_sta();       // Buat default WiFi station interface

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));  // Inisialisasi WiFi dengan config default

    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;

    // Register event handler untuk event WiFi
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                         ESP_EVENT_ANY_ID,
                                                         &event_handler,
                                                         NULL,
                                                         &instance_any_id));
    // Register event handler untuk event IP
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                         IP_EVENT_STA_GOT_IP,
                                                         &event_handler,
                                                         NULL,
                                                         &instance_got_ip));

    // Konfigurasi WiFi
    wifi_config_t wifi_config = {
        .sta = {
            .ssid = EXAMPLE_ESP_WIFI_SSID,
            .password = EXAMPLE_ESP_WIFI_PASS,
            .threshold.authmode = WIFI_AUTH_WPA2_PSK,
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));               // Set mode station
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config)); // Set config
    ESP_ERROR_CHECK(esp_wifi_start());                               // Start WiFi

    ESP_LOGI(TAG, "wifi_init_sta finished.");

    // Tunggu event connected atau fail
    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
                                           WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                           pdFALSE,
                                           pdFALSE,
                                           portMAX_DELAY);

    if (bits & WIFI_CONNECTED_BIT) {
        ESP_LOGI(TAG, "connected to ap SSID:%s", EXAMPLE_ESP_WIFI_SSID);
    } else if (bits & WIFI_FAIL_BIT) {
        ESP_LOGI(TAG, "Failed to connect to SSID:%s", EXAMPLE_ESP_WIFI_SSID);
    } else {
        ESP_LOGE(TAG, "UNEXPECTED EVENT");
    }
}

// --- MQTT ---
// Fungsi untuk log error jika error code bukan nol
static void log_error_if_nonzero(const char *message, int error_code)
{
    if (error_code != 0) {
        ESP_LOGE(TAG, "Last error %s: 0x%x", message, error_code);
    }
}

// Publish data sensor ke MQTT broker
static void publish_sensor_data(float temperature, float humidity)
{
    if (mqtt_client == NULL) {
        ESP_LOGE(TAG, "MQTT client not initialized");
        return;
    }

    char payload[100];
    // Format payload JSON
    snprintf(payload, sizeof(payload),
             "{\"INIUMAR\":\"2 RPK\", \"temperature\": %.1f, \"humidity\": %.1f}",
             temperature, humidity);

    int retry = 0;
    int msg_id = -1;
    // Retry publish hingga 3 kali jika gagal
    while (retry < 3 && msg_id == -1) {
        msg_id = esp_mqtt_client_publish(mqtt_client, "/2rpk/random", payload, 0, 1, 0);
        if (msg_id == -1) {
            ESP_LOGW(TAG, "Publish failed, retrying...");
            vTaskDelay(2000 / portTICK_PERIOD_MS);
        }
        retry++;
    }

    ESP_LOGI(TAG, "Published sensor data: %s, msg_id=%d", payload, msg_id);
}

// Event handler untuk event MQTT
static void mqtt_event_handler(void *handler_args, esp_event_base_t base,
                               int32_t event_id, void *event_data)
{
    ESP_LOGD(TAG, "Event dispatched from event loop base=%s, event_id=%" PRIi32, base, event_id);
    esp_mqtt_event_handle_t event = event_data;

    switch ((esp_mqtt_event_id_t)event_id) {
    case MQTT_EVENT_CONNECTED:
        ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
        break;

    case MQTT_EVENT_DISCONNECTED:
        ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED");
        break;

    case MQTT_EVENT_SUBSCRIBED:
        ESP_LOGI(TAG, "MQTT_EVENT_SUBSCRIBED, msg_id=%d", event->msg_id);
        break;

    case MQTT_EVENT_UNSUBSCRIBED:
        ESP_LOGI(TAG, "MQTT_EVENT_UNSUBSCRIBED, msg_id=%d", event->msg_id);
        break;

    case MQTT_EVENT_PUBLISHED:
        ESP_LOGI(TAG, "MQTT_EVENT_PUBLISHED, msg_id=%d", event->msg_id);
        break;

    case MQTT_EVENT_DATA:
        ESP_LOGI(TAG, "MQTT_EVENT_DATA");
        printf("TOPIC=%.*s\r\n", event->topic_len, event->topic);
        printf("DATA=%.*s\r\n", event->data_len, event->data);
        break;

    case MQTT_EVENT_ERROR:
        ESP_LOGI(TAG, "MQTT_EVENT_ERROR");
        if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
            log_error_if_nonzero("reported from esp-tls", event->error_handle->esp_tls_last_esp_err);
            log_error_if_nonzero("reported from tls stack", event->error_handle->esp_tls_stack_err);
            log_error_if_nonzero("captured as transport's socket errno", event->error_handle->esp_transport_sock_errno);
            ESP_LOGI(TAG, "Last errno string (%s)", strerror(event->error_handle->esp_transport_sock_errno));
        }
        break;

    default:
        ESP_LOGI(TAG, "Other event id:%d", event->event_id);
        break;
    }
}

// Start aplikasi MQTT client
static void mqtt_app_start(void)
{
    // Konfigurasi MQTT client
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = "mqtt://datakecil.my.id",
        .broker.address.port = 1883,
        .credentials.username = "nugroho",
        .credentials.client_id = "mqttx_3df7080e",
        .credentials.authentication.password = "admin",
    };

    ESP_LOGI(TAG, "Connecting to MQTT broker at: %s", mqtt_cfg.broker.address.uri);

    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);  // Inisialisasi client MQTT
    if (mqtt_client == NULL) {
        ESP_LOGE(TAG, "Failed to initialize MQTT client");
        return;
    }

    // Register event handler MQTT
    esp_mqtt_client_register_event(mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    esp_err_t err = esp_mqtt_client_start(mqtt_client);  // Start client MQTT
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to start MQTT client with error: %s", esp_err_to_name(err));
    }
}

// --- TASK DHT22 ---
// Task untuk membaca sensor DHT22
void dht_sensor_task(void *pvParameter)
{
    setDHTgpio(DHT_GPIO);  // Set pin GPIO untuk DHT22
    ESP_LOGI(TAG, "Starting DHT Sensor Task");

    while (1) {
        int ret = readDHT();  // Baca data dari DHT22
        if (ret == DHT_OK) {
            float humidity = getHumidity();      // Dapatkan kelembapan
            float temperature = getTemperature();// Dapatkan suhu
            oled_show_time_temp_hum(temperature, humidity); // Tampilkan jam & sensor ke OLED
            publish_sensor_data(temperature, humidity); // Publish ke MQTT
        } else {
            ESP_LOGE(TAG, "DHT sensor read error: %d", ret);
        }
        vTaskDelay(10000 / portTICK_PERIOD_MS);  // Delay 10 detik
    }
}

// --- APP MAIN ---
// Fungsi utama aplikasi
void app_main(void)
{
    ESP_LOGI(TAG, "[APP] Startup..");
    ESP_LOGI(TAG, "[APP] Free memory: %" PRIu32 " bytes", esp_get_free_heap_size());
    ESP_LOGI(TAG, "[APP] IDF version: %s", esp_get_idf_version());

    esp_log_level_set("*", ESP_LOG_INFO);           // Set log level info untuk semua
    esp_log_level_set("mqtt_client", ESP_LOG_VERBOSE); // Set log level verbose untuk MQTT

    ESP_ERROR_CHECK(nvs_flash_init());              // Inisialisasi NVS flash
    ESP_ERROR_CHECK(esp_netif_init());              // Inisialisasi network interface
    ESP_ERROR_CHECK(esp_event_loop_create_default()); // Buat default event loop

    // Inisialisasi OLED (pastikan ssd1306.c juga pakai pin 10/8)
    ssd1306_init();
    ssd1306_draw_string(0, 0, "OLED Ready", 1, 0);
    ssd1306_refresh_gram();

    wifi_init_sta();    // Inisialisasi WiFi station
    mqtt_app_start();   // Start aplikasi MQTT

    obtain_time(); // Sinkronisasi waktu NTP

    // Set zona waktu ke WIB (GMT+7)
    setenv("TZ", "WIB-7", 1);
    tzset();

    vTaskDelay(5000 / portTICK_PERIOD_MS);  // Delay 5 detik
    // Buat task untuk membaca sensor DHT22
    xTaskCreate(dht_sensor_task, "dht_sensor_task", 4096, NULL, 5, NULL);
}