#ifndef SSD1306_H
#define SSD1306_H

#include <stdint.h>
#include <stdbool.h>

#define SSD1306_I2C_ADDRESS 0x3C // Alamat default OLED 128x64 I2C

void ssd1306_init(void);
void ssd1306_clear_screen(void);
void ssd1306_draw_string(uint8_t x, uint8_t y, const char *str, uint8_t size, bool mode);
void ssd1306_refresh_gram(void);

#endif